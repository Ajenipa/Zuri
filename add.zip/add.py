num1 = 20
num2 = 50
sum = num1 + num2
print(sum)
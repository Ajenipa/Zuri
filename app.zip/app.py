first_user_input = int(input("please enter a number :"))
second_user_input = int(input("please enter a number :"))
addition = first_user_input+second_user_input
subtraction = first_user_input-second_user_input
multiplication = first_user_input*second_user_input
division = first_user_input/second_user_input
modulus = first_user_input%second_user_input
print("addition: "+str(addition))
print("subtraction: "+str(subtraction))
print("multiplication: "+str(multiplication))
print("division: "+str(division))
print("Modulus: "+str(modulus))